#from distutils.core import setup
from setuptools import setup
setup(
    name='fua',
    version='1.0.0',
    packages=[''],
    url='https://github.com/behdadahmadi',
    license='MIT',
    author='Behdad Ahmadi',
    author_email='behdadahmadi@mail.com',
    description='Fake User-Agents of many real devices'
)
